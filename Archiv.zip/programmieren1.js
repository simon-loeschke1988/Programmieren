//Das hier ist ein Kommentar

/* Autor: Simon Löschke
Datum: 10.08.2025
Grundkurs JS */

// Hello World auf die Console ausgeben!

console.log("Hallo Welt!");

//Einführung in Variablen

//var Nutzereingabe = prompt("Bitte gib deinen Namen ein: ");

//element = document.getElementById("test");
//element.innerHTML = Nutzereingabe;

//console.log("Hallo " + Nutzereingabe);

// Datentypen

//String (engl. Textkette)

var text = "Das ist ein Text.";
var ganzzahl = 2; // Integer
var kommazahl = 2.1; // Float
var wahrheitswert = true; // anderer wert: false Bolean
var liste = ["Banane", "Apfel", "Birne"]; // Array

// Werte aus Variablen mit verschiedenen Datentypen ausgeben:

var nutzereingabe1 = prompt("Gib deine erste Zahl ein: ");
var nutzereingabe2 = prompt("Gib deine zweite Zahl ein: ");
var produkt = nutzereingabe1 * nutzereingabe2;

console.log(produkt);